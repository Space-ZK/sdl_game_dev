//
//  MapLoader.h
//  SDL Game Programming Book
//
//  Created by shaun mitchell on 09/03/2013.
//  Copyright (c) 2013 shaun mitchell. All rights reserved.
//

#ifndef __SDL_Game_Programming_Book__MapLoader__
#define __SDL_Game_Programming_Book__MapLoader__

#include <iostream>
//#include "Map.h"
#include "tinyxml.h"

class MapLoader
{
public:
    
    //Map* loadMap(const char* mapFile);
    
private:
    
    //void parseTextures(TiXmlElement* pTilesetRoot, Map::Tilesets *pTextureIDs);
    //void parseLayer(std::vector<int> layerData, Map::GridIDs *pLayers);
    
};

#endif /* defined(__SDL_Game_Programming_Book__MapLoader__) */
