//
//  GameObjectFactory.cpp
//  SDL Game Programming Book
//
//  Created by shaun mitchell on 26/02/2013.
//  Copyright (c) 2013 shaun mitchell. All rights reserved.
//

#include "GameObjectFactory.h"

GameObjectFactory* GameObjectFactory::pInstance = 0;
